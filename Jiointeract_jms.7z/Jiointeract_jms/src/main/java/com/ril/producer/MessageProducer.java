package com.ril.producer;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

import com.ril.controller.MessageController;

@Component
public class MessageProducer {

	private static final Logger logger = LoggerFactory.getLogger(MessageController.class);
	@Autowired
	private JmsTemplate jmsTemplate;
	
	public void pushToQueue(String message) {
		this.jmsTemplate.setSessionAcknowledgeMode(Session.AUTO_ACKNOWLEDGE);
		try {
			jmsTemplate.send("sample", new MessageCreator() {
				public Message createMessage(Session session) throws JMSException {
					return session.createTextMessage(message);
				}
			});
			logger.debug("Message Pushed To Queue "+message);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
		
	}
}
