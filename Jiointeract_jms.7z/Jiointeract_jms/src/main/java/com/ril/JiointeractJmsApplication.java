package com.ril;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;

import com.tibco.tibjms.TibjmsConnectionFactory;

@SpringBootApplication
public class JiointeractJmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(JiointeractJmsApplication.class, args);
	}
	@Bean
	public ConnectionFactory activeMQConnectionFactory() throws JMSException {
		TibjmsConnectionFactory factory = new TibjmsConnectionFactory("tcp://localhost:7222");
		factory.setUserName("admin");
		factory.setUserPassword("admin");
		return factory;
	}

	@Bean
	public JmsTemplate template() throws JMSException {
		JmsTemplate jmsTemplate = new JmsTemplate();
		CachingConnectionFactory ccf = new CachingConnectionFactory();
		ccf.setTargetConnectionFactory(activeMQConnectionFactory());
		jmsTemplate.setConnectionFactory(ccf);
		jmsTemplate.setPubSubDomain(false);
		return jmsTemplate;
	}
}
