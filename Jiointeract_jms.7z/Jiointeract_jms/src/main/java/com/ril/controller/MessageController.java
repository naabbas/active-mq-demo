package com.ril.controller;

import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.ril.producer.MessageProducer;
import com.ril.services.MessagesService;


@RestController()
public class MessageController {
	private static final Logger logger = LoggerFactory.getLogger(MessageController.class);
	
	@Autowired
	MessagesService service;
	
	@PostMapping(value = "/postMessages",consumes = MediaType.APPLICATION_JSON_VALUE)
	public String postMessage(@RequestBody String message) {
		logger.debug("/post message"+ message);
		try {
			JSONObject json=new JSONObject();
			
			String transactionId=service.covertAndSend(message);
			json.append("status", "Success");
			json.append("Tranasaction ID", transactionId);
			logger.debug("Tranasaction ID : "+transactionId);
			return json.toString(4);
			
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
		}
	}

}
