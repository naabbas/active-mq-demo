package com.ril.services;

import java.io.IOException;
import java.io.StringReader;
import java.util.UUID;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.ril.controller.MessageController;
import com.ril.producer.MessageProducer;

@Service
public class MessagesService {
	private static final Logger logger = LoggerFactory.getLogger(MessageController.class);
	@Autowired
	MessageProducer producer;
	
	public String covertAndSend(String message) throws ParserConfigurationException, SAXException, IOException {
		logger.debug("inside serive class generating uuid");
		JSONObject json=new JSONObject(message);
		String transactionId=UUID.randomUUID().toString();
		json.append("transactionId", transactionId);
		String xml=XML.toString(json);
		logger.debug("inside serive class transaction ");
		producer.pushToQueue(xml);
		return transactionId;
	}
}
